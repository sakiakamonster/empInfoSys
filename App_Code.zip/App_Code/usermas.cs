﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for usermas
/// </summary>
public class usermas
{
    private string _uid;
    private string _pwd;
    private string _uname;
    private string _uadd;
    private string _uphno;
    private string _uemail;
    private string _ugen;
    private string _udob;
    private string _uphoto;
    private string _status;
    private string _eid;

    public string uid
    {
        set { _uid = value; }
        get { return _uid; }
    }
    public string pwd
    {
        set { _pwd = value; }
        get { return _pwd; }
    }
    public string uname
    {
        set { _uname = value; }
        get { return _uname; }
    }
    public string uadd
    {
        set { _uadd = value; }
        get { return _uadd; }
    }
    public string uphno
    {
        set { _uphno = value; }
        get { return _uphno; }
    }
    public string uemail
    {
        set { _uemail = value; }
        get { return _uemail; }
    }
    public string ugen
    {
        set { _ugen = value; }
        get { return _ugen; }
    }
    public string udob
    {
        set { _udob = value; }
        get { return _udob; }
    }
  
    public string uphoto
    {
        set { _uphoto = value; }
        get { return _uphoto; }
    }
    public string status
    {
        set { _status = value; }
        get { return _status; }
    }
    public string eid
    {
        set { _eid = value; }
        get { return _eid; }
    }

}