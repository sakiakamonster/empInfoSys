﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;
/// <summary>
/// Summary description for sqlHelper
/// </summary>
public class sqlHelper
{
    public SqlConnection cn;
    public SqlCommand cm;
    public SqlDataAdapter da;
    public DataSet ds = new DataSet();
    public sqlHelper()
    {
        cn = new SqlConnection(WebConfigurationManager.ConnectionStrings["myCon"].ConnectionString);
        cn.Open();
    }
    public usermas usrAssign(string uid, string pwd, string uname, string uadd, string uph, string uem, string gen, string dob, string phto, string sta, string eid)
    {
        usermas ob = new usermas();
        ob.uid = uid;
        ob.pwd = pwd;
        ob.uname = uname;
        ob.uadd = uadd;
        ob.uphno = uph;
        ob.uemail = uem;
        ob.ugen = gen;
        ob.udob = dob;
        ob.uphoto = phto;
        ob.status = sta;
        ob.eid = eid;
        return ob;
    }
    public void usrOp(usermas usr, char action)
    {
        cm = new SqlCommand();
        cm.Connection = cn;
        cm.CommandType = CommandType.StoredProcedure;

        cm.CommandText = "sp_user_op";
        cm.Parameters.AddWithValue("@uid", usr.uid);
        cm.Parameters.AddWithValue("@pwd", usr.pwd);
        cm.Parameters.AddWithValue("@uname", usr.uname);
        cm.Parameters.AddWithValue("@uadd", usr.uadd);
        cm.Parameters.AddWithValue("@uphone", usr.uphno);
        cm.Parameters.AddWithValue("@uemail", usr.uemail);
        cm.Parameters.AddWithValue("@ugen", usr.ugen);
        cm.Parameters.AddWithValue("@udob", usr.udob);
        cm.Parameters.AddWithValue("@uphoto", usr.uphoto);
        cm.Parameters.AddWithValue("@ustatus", usr.status);
        cm.Parameters.AddWithValue("@empid", usr.eid);
        cm.Parameters.AddWithValue("@action", action);
        if (action == 'I' || action == 'U' || action == 'D' || action == 'C' || action == 'P')
            cm.ExecuteNonQuery();
        else if (action == 'S' || action == 'A' || action == 'N' || action == 'L' || action == 'E')
        {
            da = new SqlDataAdapter(cm);
            ds.Clear();
            ds.Reset();
            da.Fill(ds);
        }

    }

    public empmas empAssign(string eid, string ename, string eadd, string eph, string eem, string gen, int age, string doj, string dept, string phto)
    {
        empmas ob = new empmas();
        ob.eid = eid;
        ob.ename = ename;
        ob.eadd = eadd;
        ob.ephno = eph;
        ob.eemail = eem;
        ob.egen = gen;
        ob.eage = age;
        ob.edoj = doj;
        ob.edept = dept;
        ob.ephoto = phto;
        return ob;
    }

    public salMas salAssign(string eid, string mon, string yr, double sal, double ded, double allow, double nsal)
    {
        salMas ob = new salMas();
        ob.eid = eid;
        ob.emon = mon;
        ob.eyr = yr;
        ob.sal = sal;
        ob.ded = ded;
        ob.allow = allow;
        ob.nsal = nsal;
        return ob;
    }
    public void empOp(empmas emp, char action)
    {
        cm = new SqlCommand();
        cm.Connection = cn;
        cm.CommandType = CommandType.StoredProcedure;

        cm.CommandText = "sp_emp_op";
        cm.Parameters.AddWithValue("@eid", emp.eid);
        cm.Parameters.AddWithValue("@ename", emp.ename);
        cm.Parameters.AddWithValue("@eadd", emp.eadd);
        cm.Parameters.AddWithValue("@ephone", emp.ephno);
        cm.Parameters.AddWithValue("@eemail", emp.eemail);
        cm.Parameters.AddWithValue("@egen", emp.egen);
        cm.Parameters.AddWithValue("@eage", emp.eage);
        cm.Parameters.AddWithValue("@edoj", Convert.ToDateTime(emp.edoj));
        cm.Parameters.AddWithValue("@edept", emp.edept);
        cm.Parameters.AddWithValue("@ephoto", emp.ephoto);
        cm.Parameters.AddWithValue("@action", action);
        if (action == 'I' || action == 'U' || action == 'D')
            cm.ExecuteNonQuery();
        else if (action == 'S' || action == 'A')
        {
            da = new SqlDataAdapter(cm);
            ds.Clear();
            ds.Reset();
            da.Fill(ds);
        }

    }

    public void salOp(salMas sal, char action)
    {
        cm = new SqlCommand();
        cm.Connection = cn;
        cm.CommandType = CommandType.StoredProcedure;

        cm.CommandText = "sp_sal_op";
        cm.Parameters.AddWithValue("@eid", sal.eid);
        cm.Parameters.AddWithValue("@emon", sal.emon);
        cm.Parameters.AddWithValue("@eyr", sal.eyr);
        cm.Parameters.AddWithValue("@esal", sal.sal);
        cm.Parameters.AddWithValue("@ded", sal.ded);
        cm.Parameters.AddWithValue("@alw", sal.allow);
        cm.Parameters.AddWithValue("@nsal", sal.nsal);
        cm.Parameters.AddWithValue("@action", action);
        if (action == 'I' || action == 'U' || action == 'D')
            cm.ExecuteNonQuery();
        else if (action == 'S' || action == 'A')
        {
            da = new SqlDataAdapter(cm);
            ds.Clear();
            ds.Reset();
            da.Fill(ds);
        }

    }
}