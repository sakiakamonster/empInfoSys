﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for attendance
/// </summary>
public class attendance
{
    private string _eid;
    private string _doa;
    private string _status;

    public string eid
    {
        set { _eid = value; }
        get { return _eid; }
    }
    public string doa
    {
        set { _doa = value; }
        get { return _doa; }
    }
    public string status
    {
        set { _status = value; }
        get { return _status; }
    }
}