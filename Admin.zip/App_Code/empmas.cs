﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for empmas
/// </summary>
public class empmas
{
    private string _eid;
    private string _ename;
    private string _eadd;
    private string _ephno;
    private string _eemail;
    private string _egen;
    private int _eage;
    private string _edoj;
    private string _edept;
    private string _ephoto;
    public string eid
    {
        set { _eid = value; }
        get { return _eid; }
    }
    public string ename
    {
        set { _ename = value; }
        get { return _ename; }
    }
    public string eadd
    {
        set { _eadd = value; }
        get { return _eadd; }
    }
    public string ephno
    {
        set { _ephno = value; }
        get { return _ephno; }
    }
    public string eemail
    {
        set { _eemail = value; }
        get { return _eemail; }
    }
    public string egen
    {
        set { _egen = value; }
        get { return _egen; }
    }
    public int eage
    {
        set { _eage = value; }
        get { return _eage; }
    }
    public string edoj
    {
        set { _edoj = value; }
        get { return _edoj; }
    }
    public string edept
    {
        set { _edept = value; }
        get { return _edept; }
    }
    public string ephoto
    {
        set { _ephoto = value; }
        get { return _ephoto; }
    }
}