﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for salMas
/// </summary>
public class salMas
{
    private string _eid;
    private string _emon;
    private string _eyr;
    private double _sal;
    private double _ded;
    private double _allow;
    private double _nsal;
    public string eid
    {
        set { _eid = value; }
        get { return _eid; }
    }
    public string emon
    {
        set { _emon = value; }
        get { return _emon; }
    }
    public string eyr
    {
        set { _eyr = value; }
        get { return _eyr; }
    }
    public double sal
    {
        set { _sal = value; }
        get { return _sal; }
    }
    public double ded
    {
        set { _ded = value; }
        get { return _ded; }
    }
    public double allow
    {
        set { _allow = value; }
        get { return _allow; }
    }
    public double nsal
    {
        set { _nsal = value; }
        get { return _nsal; }
    }
}