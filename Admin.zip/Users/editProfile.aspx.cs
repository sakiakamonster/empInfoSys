﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Users_editProfile : System.Web.UI.Page
{
    sqlHelper ob = new sqlHelper();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            fillboxes();
    }
    private void fillboxes()
    {
        usermas usr = ob.usrAssign(Session["uid"].ToString (), "", "", "", "", "", "", "", "", "", "");
        ob.usrOp(usr, 'S');
        txtUAdd.Text = ob.ds.Tables[0].Rows[0].ItemArray[3].ToString();
        txtUPhone.Text = ob.ds.Tables[0].Rows[0].ItemArray[4].ToString();
        txtUEmail.Text = ob.ds.Tables[0].Rows[0].ItemArray[5].ToString();
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        try
        {
            usermas usr = ob.usrAssign(Session["uid"].ToString(), "", "", txtUAdd.Text, txtUPhone.Text, txtUEmail.Text, "", "", "", "", "");
            ob.usrOp(usr, 'U');
            lblMsg.Text = "Profile Edited";
        }
        catch (Exception ex)
        {
            lblMsg.Text = "Error : " + ex.Message;
        }
    }
}