
function notEmpty(elem,msg)
{
if(elem.value.length==0)
{
alert(msg);
elem.focus();
return false;
}
return true;
}
function onlyDigits(elem,msg)
{
var exp=/^[0-9]+$/;
if(!elem.value.match(exp))
{
alert(msg);
elem.focus();
return false;
}
return true;
}
function onlyAlpha(elem,msg)
{
var exp=/^[a-z A-Z]+$/;
if(!elem.value.match(exp))
{
alert(msg);
elem.focus();
return false;
}
return true;
}
function alphaNum(elem,msg)
{
var exp=/^[a-z A-Z0-9\,\-\/\:]+$/;
if(!elem.value.match(exp))
{
alert(msg);
elem.focus();
return false;
}
return true;
}
function lengthRestrict(elem,min,max)
{
if(!(elem.value.length>=min && elem.value.length<=max))
{
alert("Password Between "+ min + " and "+ max + "Chars");
elem.focus();
return false;
}
return true;
}
function compVal(elem1,elem2,msg)
{
if(!(elem1.value==elem2.value))
{
alert(msg);
elem1.focus();
return false;
}
return true;
}
function mustSelect(elem,msg)
{
if(elem.value=="Select One")
{
alert(msg);
elem.focus();
return false;
}
return true;
}
function validEmail(elem,msg)
{
var exp=/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
if(!elem.value.match(exp))
{
alert(msg);
elem.focus();
return false;
}
return true;
}