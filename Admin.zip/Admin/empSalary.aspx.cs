﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class templateField : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    sqlHelper obj = new sqlHelper();
    protected void ddlMonth_SelectedIndexChanged(object sender, EventArgs e)
    {
     empmas emp=   obj.empAssign("","","","","","",0,DateTime.Now.ToString (),"","");
     obj.empOp(emp, 'A');
     grdvSal.DataSource = obj.ds.Tables[0];
     grdvSal.DataBind();
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        foreach (GridViewRow r in grdvSal.Rows)
        {
            string eid = r.Cells[0].Text;
            string emon = ddlMonth.SelectedValue.ToString();
            string eyr = DateTime.Now.Year.ToString();
            TextBox t = (TextBox)r.FindControl("txtSal");
            double esal = Convert.ToDouble(t.Text);
             t = (TextBox)r.FindControl("txtDed");
            double eded = Convert.ToDouble(t.Text);
             t = (TextBox)r.FindControl("txtAllow");
            double eallow = Convert.ToDouble(t.Text);
             t = (TextBox)r.FindControl("txtNSal");
            double ensal = Convert.ToDouble(t.Text);
           salMas sal= obj.salAssign(eid, emon, eyr, esal, eded, eallow, ensal);
           obj.salOp(sal, 'I');
        }
        lblMsg.Text = "Salary Inserted";
    }
}