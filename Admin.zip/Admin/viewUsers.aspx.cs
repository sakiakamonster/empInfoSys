﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_viewUsers : System.Web.UI.Page
{
    sqlHelper ob = new sqlHelper();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
            fillgrid();
    }
    private void fillgrid()
    {
        usermas usr = ob.usrAssign("", "", "", "", "", "", "", "", "", "", "");
        ob.usrOp(usr, 'N');
        GridView1.DataSource = ob.ds.Tables[0];
        GridView1.DataBind();
    }
    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        usermas usr = ob.usrAssign(GridView1.Rows[e.NewSelectedIndex].Cells[0].Text , "", "", "", "", "", "", "", "", "", "");
        ob.usrOp(usr, 'P');
        fillgrid();
    }
}