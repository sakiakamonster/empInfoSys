﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default4 : System.Web.UI.Page
{
    static sqlHelper ob = new sqlHelper();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (!IsPostBack)
        {
            fillGrid();
            hide();
        }
    }
    private void hide()
    {
        btnInsert.Enabled = true;
        btnDelete.Enabled = false;
        btnUpdate.Enabled = false;
        txtEmpId.ReadOnly = false;        
    }
    private void show()
    {
        btnInsert.Enabled = false;
        btnDelete.Enabled = true;
        btnUpdate.Enabled = true;
        txtEmpId.ReadOnly = true;
    }
    private void reset()
    {
        txtEmpId.Text = "";
        txtEmpName.Text = "";
        txtEmpAdd.Text = "";
        txtEmpPhone.Text = "";
        txtEmpEmail.Text = "";
        rdlEmpGen.SelectedIndex = 0;
        txtEmpAge.Text = "";
        txtEmpDoj.Text = "";
        ddlEmpDept.SelectedIndex = 0;
        txtEmpId.Focus ();
    }
    private void fillGrid()
    {

        ob.empOp("", "", "", "", "", "", 0, DateTime.Now.ToString(), "", "", 'A');
        GridView1.DataSource = ob.ds.Tables[0];
        GridView1.DataBind();
    }
    protected void btnInsert_Click(object sender, EventArgs e)
    {
        ob.empOp(txtEmpId.Text, "", "", "", "", "", 0, DateTime.Now.ToString(), "", "", 'S');
        if (ob.ds.Tables[0].Rows.Count > 0)
        {
            lblMsg.Text = "Duplicate Emplotyee ID";
            txtEmpId.Focus();
            return;
        }
        ob.empOp(txtEmpId.Text, txtEmpName.Text, txtEmpAdd.Text, txtEmpPhone.Text, txtEmpEmail.Text, rdlEmpGen.SelectedValue.ToString(), Convert.ToInt32(txtEmpAge.Text), txtEmpDoj.Text, ddlEmpDept.SelectedValue.ToString(), fuEmpPhoto.FileName, 'I');
        fillGrid();
        hide();
        reset();
        lblMsg.Text = "Employee Inserted Successfully";
        fuEmpPhoto.PostedFile.SaveAs(Server.MapPath(".") + "\\empphoto\\" + fuEmpPhoto.FileName);
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        reset();
    }
    static string imgrl = "";
    protected void GridView1_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
    {
        txtEmpId.Text = GridView1.Rows[e.NewSelectedIndex].Cells[0].Text;
        txtEmpName.Text = GridView1.Rows[e.NewSelectedIndex].Cells[1].Text;
        txtEmpAdd.Text = GridView1.Rows[e.NewSelectedIndex].Cells[2].Text;
        txtEmpPhone.Text = GridView1.Rows[e.NewSelectedIndex].Cells[3].Text;
        txtEmpEmail.Text = GridView1.Rows[e.NewSelectedIndex].Cells[4].Text;
        rdlEmpGen.Text = GridView1.Rows[e.NewSelectedIndex].Cells[5].Text;
        txtEmpAge.Text = GridView1.Rows[e.NewSelectedIndex].Cells[6].Text;
        txtEmpDoj.Text = GridView1.Rows[e.NewSelectedIndex].Cells[7].Text;
        ddlEmpDept.Text = GridView1.Rows[e.NewSelectedIndex].Cells[8].Text;
        Image1.ImageUrl="empphoto/" + GridView1.Rows[e.NewSelectedIndex].Cells[9].Text;
        imgrl=GridView1.Rows[e.NewSelectedIndex].Cells[9].Text;
        show();
        photo = GridView1.Rows[e.NewSelectedIndex].Cells[9].Text;
    }
    static string photo = "";
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        

        if (fuEmpPhoto.HasFile)
        {
            photo = fuEmpPhoto.FileName;
            fuEmpPhoto.PostedFile.SaveAs(Server.MapPath(".") + "\\empphoto\\" + fuEmpPhoto.FileName);
        }
        

        ob.empOp(txtEmpId.Text, txtEmpName.Text, txtEmpAdd.Text, txtEmpPhone.Text, txtEmpEmail.Text, rdlEmpGen.SelectedValue.ToString(), Convert.ToInt32(txtEmpAge.Text), txtEmpDoj.Text, ddlEmpDept.SelectedValue.ToString(), photo, 'U');
                fillGrid();
        hide();
        reset();
        lblMsg.Text = "Employee Updated Successfully";        
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        ob.empOp(txtEmpId.Text, "", "", "", "", "", 0, DateTime.Now.ToString(), "", "", 'D');
        lblMsg.Text = "Employee Deleted Successfully";
       
        fillGrid();
        hide();
        reset();
    }
}