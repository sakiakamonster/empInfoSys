﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Users_changePass : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    sqlHelper ob = new sqlHelper();
    protected void btnChange_Click(object sender, EventArgs e)
    {
        try
        {
            usermas usr = ob.usrAssign(Session["uid"].ToString(), txtCurPass.Text, "", "", "", "", "", "", "", "", "");
            ob.usrOp(usr, 'L');
            if (ob.ds.Tables[0].Rows.Count > 0)
            {
                usr = ob.usrAssign(Session["uid"].ToString(), txtNewPwd.Text, "", "", "", "", "", "", "", "", "");
                ob.usrOp(usr, 'C');
                lblMsg.Text = "Password Changed Successfully";
            }
            else
            {
                lblMsg.Text = "Invalid Current Password";
                txtCurPass.Focus();
                return;
            }
        }
        catch (Exception ex)
        {
            lblMsg.Text = "Error : " + ex.Message;
        }

    }
}